wget "http://supermoe.cs.umass.edu/682/asgns/coco_captioning.zip"
unzip coco_captioning.zip
rm coco_captioning.zip

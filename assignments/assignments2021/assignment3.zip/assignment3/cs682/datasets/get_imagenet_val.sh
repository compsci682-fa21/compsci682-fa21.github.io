wget http://supermoe.cs.umass.edu/682/asgns/imagenet_val_25.npz
